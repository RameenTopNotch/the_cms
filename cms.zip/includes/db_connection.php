<?php
    $connection = mysqli_connect('localhost', 'root',
        '', 'cms') or die(mysqli_error($connection));